# Cargo Documentation

NOTE: Cargo documentation is under migration to mdBook-based structure. All the
`*.md` files here shall be kept in sync with the `*.md` files under `book/src/`.
See `MIGRATION_MAP` file here and <https://github.com/rust-lang/cargo/pull/4453>
for details.
